from sqlalchemy import create_engine, Column, Integer, String, ForeignKey, select
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship

from game import Game
from player import Player
from weapon import Weapon
from vessel import Vessel
from battlefield import Battlefield

engine = create_engine('sqlite:////tmp/tdlog.db', echo=True, future=True)
Base = declarative_base(bind=engine)
Session = sessionmaker(bind=engine)


class GameEntity(Base):
    __tablename__ = 'game'
    id = Column(Integer, primary_key=True)
    players = relationship("PlayerEntity", back_populates="game",
                           cascade="all, delete-orphan")


class PlayerEntity(Base):
    __tablename__ = 'player'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    game_id = Column(Integer, ForeignKey("game.id"), nullable=False)
    game = relationship("GameEntity", back_populates="players")
    battle_field = relationship("BattlefieldEntity",
                                back_populates="player",
                                uselist=False, cascade="all, delete-orphan")


class BattlefieldEntity(Base):
    __tablename__ = 'battlefield'
    id = Column(Integer, primary_key=True)
    min_x = Column(Integer, nullable=False)
    min_y = Column(Integer, nullable=False)
    min_z = Column(Integer, nullable=False)
    max_x = Column(Integer, nullable=False)
    max_y = Column(Integer, nullable=False)
    max_z = Column(Integer, nullable=False)
    max_power = Column(Integer, nullable=False)
    player_id = Column(Integer, ForeignKey("player.id"), nullable=False)


class VesselEntity(Base):
    __tablename__ = 'vessel'
    id = Column(Integer, primary_key=True)
    coord_x = Column(Integer, nullable=False)
    coord_y = Column(Integer, nullable=False)
    coord_z = Column(Integer, nullable=False)
    hits_to_be_destroyed = Column(Integer, nullable=False)
    type = Column(String, nullable=False)
    player_id = Column(Integer, ForeignKey("player.id"), nullable=False)


class WeaponEntity:
    __tablename_ = 'weapon'
    id = Column(Integer, primary_key=True)
    ammunitions = Column(Integer, nullable=False)
    range = Column(Integer, nullable=False)
    type = Column(Integer, nullable=False)
    vessel_id = Column(Integer, ForeignKey("vessel.id"), nullable=False)


def map_to_game(game: GameEntity):
    the_game = Game(game.id)
    the_players = game.players
    for i in range(len(the_players)):
        the_game.add_player(the_players[i])
    return the_game


def map_to_game_entity(self,game:Game):
        game_entity = GameEntity()
        game_entity.id = game.id
        game_entity.player = game.players
        return game_entity

def map_to_weapon(weapon: WeaponEntity):
    result=Weapon()
    return result


def map_to_vessel(weapon_entity: WeaponEntity, vessel_entity: VesselEntity):
    weapon = Weapon(weapon_entity.id,weapon_entity.ammunitions,weapon_entity.range)
    result = Vessel(vessel_entity.id,vessel_entity.coord_x,vessel_entity.coord_y,vessel_entity.coord_z,vessel_entity.hits_to_be_destroyed,weapon)
    type(result.weapon).__name__ = weapon_entity.type
    type(result).__name__= vessel_entity.type
    return result


def map_to_vessel_entity(battlefield_id: int, vessel: Vessel):
    vessel_entity = VesselEntity()
    weapon_entity = WeaponEntity()
    weapon_entity.id = vessel.weapon.id
    weapon_entity.ammunitions = vessel.weapon.ammunitions
    weapon_entity.range = vessel.weapon.range
    weapon_entity.type = type(vessel.weapon).__name__
    vessel_entity.id = vessel.id
    vessel_entity.weapon = weapon_entity
    vessel_entity.type = type(vessel).__name__
    vessel_entity.hits_to_be_destroyed = vessel.hits_to_be_destroyed
    vessel_entity.coord_x = vessel.coordinates[0]
    vessel_entity.coord_y = vessel.coordinates[1]
    vessel_entity.coord_z = vessel.coordinates[2]
    vessel_entity.battle_field_id = battlefield_id
    return vessel_entity


def map_to_player(player:PlayerEntity):
    result= Player()
    result.name=player.name
    result.id=player.id
    result.battle_field=player.battle_field
    return result


def map_to_player_entity(player: Player):
    player_entity = PlayerEntity()
    player_entity.id = player.id
    player_entity.name = player.name
    player_entity.battle_field = map_to_battlefield_entity(player.get_battlefield())
    return player_entity


def map_to_battlefield(battlefield: BattlefieldEntity):
    result=Battlefield(battlefield.min_x,battlefield.max_x,battlefield.min_y,battlefield.max_y,battlefield.min_z,battlefield.max_z,battlefield.max_power)
    return result

def map_to_battlefield_entity(battlefield: Battlefield):
    battlefield_entity = BattlefieldEntity()
    battlefield_entity.id = battlefield.id
    battlefield_entity.max_x = battlefield.max_x
    battlefield_entity.max_y = battlefield.max_y
    battlefield_entity.max_z = battlefield.max_z
    battlefield_entity.min_x = battlefield.min_x
    battlefield_entity.min_y = battlefield.min_y
    battlefield_entity.min_z = battlefield.min_z
    battlefield_entity.max_power = battlefield.max_power
    return battlefield_entity

class GameDao:
    def __init__(self):
        Base.metadata.create_all()
        self.db_session = Session()

    def create_game(self, game: Game) -> int:
        game_entity = map_to_game_entity(game)
        self.db_session.add(game_entity)
        self.db_session.commit()
        return game_entity.id

    def find_game(self, game_id: int) -> Game:
        stmt = select(GameEntity).where(GameEntity.id == game_id)
        game_entity = self.db_session.scalars(stmt).one()
        return map_to_game(game_entity)
